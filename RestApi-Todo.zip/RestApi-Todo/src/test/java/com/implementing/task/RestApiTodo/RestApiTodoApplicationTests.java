package com.implementing.task.RestApiTodo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiTodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
