package com.implementing.task.RestApiTodo.Todo;

import com.implementing.task.RestApiTodo.Entity.DTO.TodoDTO;
import com.implementing.task.RestApiTodo.Entity.Todo;
import com.implementing.task.RestApiTodo.controller.TodoController;
import com.implementing.task.RestApiTodo.exceptions.ResourceNotFoundException;
import com.implementing.task.RestApiTodo.repository.TodoRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

public class TodoControllerTest {
    @Mock
    private TodoRepository todoRepository;
    @Mock
    private ModelMapper modelMapper;
    @InjectMocks
    private TodoController todoController;
    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks(this);
    }
    @Test
    public void testGetById() {
        // Arrange
        int todoId = 10;

        // Create a Todo object with meaningful data
        Todo todo = new Todo();
        todo.setId(todoId);
        // Set other relevant fields for the Todo object

        // Configure the behavior of the mock objects
        when(todoRepository.findById(todoId)).thenReturn(Optional.of(todo));

        // When mapping from Todo to TodoDTO, return a new TodoDTO
        when(modelMapper.map(eq(todo), eq(TodoDTO.class))).thenReturn(new TodoDTO());

        // Act
        ResponseEntity<?> result = todoController.getById(todoId);

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        //assertNotNull(result.getBody()); // Ensure that the result body is not null
        // Add more specific assertions based on the expected content of TodoDTO
    }

    @Test
    public void testGetAll() {
        // Arrange
        Todo todo1 = new Todo();
        Todo todo2 = new Todo();
        List<Todo> todoList = Arrays.asList(todo1, todo2);

        when(todoRepository.findAll()).thenReturn(todoList);

        TodoDTO todoDTO1 = new TodoDTO();
        TodoDTO todoDTO2 = new TodoDTO();
        List<TodoDTO> expectedTodoDTOList = Arrays.asList(todoDTO1, todoDTO2);

        when(modelMapper.map(todo1, TodoDTO.class)).thenReturn(todoDTO1);
        when(modelMapper.map(todo2, TodoDTO.class)).thenReturn(todoDTO2);

        // Act
        ResponseEntity<List<TodoDTO>> result = todoController.getAll();

        // Assert
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(expectedTodoDTOList, result.getBody());
    }

    @Test
    public void testDeleteByIdSuccess() {
        // Arrange
        int todoId = 1;
        Todo todo = new Todo();
        Optional<Todo> todoOptional = Optional.of(todo);

        when(todoRepository.findById(todoId)).thenReturn(todoOptional);

        // Act
        ResponseEntity<String> result = todoController.deleteById(todoId);

        // Assert
        assertEquals("Todo deleted successfully", result.getBody());
        assertEquals(200, result.getStatusCodeValue()); // Assuming 200 is OK status
        verify(todoRepository, times(1)).deleteById(todoId);
    }



    @Test
    public void testDeleteByIdError() {
        // Arrange
        int todoId = 1;

        when(todoRepository.findById(todoId)).thenReturn(Optional.of(new Todo()));
        doThrow(new RuntimeException("Some error")).when(todoRepository).deleteById(todoId);

        // Act
        ResponseEntity<String> result = todoController.deleteById(todoId);

        // Assert
        assertEquals("Error deleting Todo: Some error", result.getBody());
        assertEquals(500, result.getStatusCodeValue()); // Assuming 500 is Internal Server Error status
        verify(todoRepository, times(1)).deleteById(todoId);
    }

    @Test
    public void testCreateTodoSuccess() {
        // Arrange
        TodoDTO todoDTO = new TodoDTO();
        Todo todo = new Todo();

        when(modelMapper.map(todoDTO, Todo.class)).thenReturn(todo);

        // Act
        ResponseEntity<String> result = todoController.createTodo(todoDTO);

        // Assert
        assertEquals("Todo created successfully", result.getBody());
        assertEquals(200, result.getStatusCodeValue()); // Assuming 200 is OK status
        verify(todoRepository, times(1)).save(todo);
    }

    @Test
    public void testCreateTodoError() {
        // Arrange
        TodoDTO todoDTO = new TodoDTO();

        when(modelMapper.map(todoDTO, Todo.class)).thenThrow(new RuntimeException("Some error"));

        // Act
        ResponseEntity<String> result = todoController.createTodo(todoDTO);

        // Assert
        assertEquals("Error creating Todo: Some error", result.getBody());
        assertEquals(500, result.getStatusCodeValue()); // Assuming 500 is Internal Server Error status
        verify(todoRepository, never()).save(any());
    }
    @Test
    public void testUpdateTodoSuccess() {
        // Arrange
        int todoId = 1;
        TodoDTO updatedTodoDTO = new TodoDTO();
        Todo existingTodo = new Todo();

        Optional<Todo> existingTodoOptional = Optional.of(existingTodo);
        when(todoRepository.findById(todoId)).thenReturn(existingTodoOptional);

        when(modelMapper.map(existingTodo, TodoDTO.class)).thenReturn(updatedTodoDTO);
        when(modelMapper.map(updatedTodoDTO, Todo.class)).thenReturn(existingTodo);

        // Act
        ResponseEntity<TodoDTO> result = todoController.updateTodo(todoId, updatedTodoDTO);

        // Assert
        assertEquals(200, result.getStatusCodeValue()); // Assuming 200 is OK status
        assertEquals(updatedTodoDTO, result.getBody());
        verify(todoRepository, times(1)).save(existingTodo);
    }

    @Test
    public void testUpdateTodoNotFound() {
        // Arrange
        int todoId = 1;

        when(todoRepository.findById(todoId)).thenReturn(Optional.empty());

        // Act
        ResponseEntity<TodoDTO> result = todoController.updateTodo(todoId, new TodoDTO());

        // Assert
        assertEquals(404, result.getStatusCodeValue()); // Assuming 404 is Not Found status
        assertNull(result.getBody());
        verify(todoRepository, never()).save(any());
    }

    @Test
    public void testUpdateTodoError() {
        // Arrange
        int todoId = 1;
        TodoDTO updatedTodoDTO = new TodoDTO();

        Optional<Todo> existingTodoOptional = Optional.of(new Todo());
        when(todoRepository.findById(todoId)).thenReturn(existingTodoOptional);

        when(modelMapper.map(any(), eq(TodoDTO.class))).thenReturn(updatedTodoDTO);
        doThrow(new RuntimeException("Some error")).when(todoRepository).save(any());

        // Act and Assert
        assertThrows(RuntimeException.class, () -> todoController.updateTodo(todoId, updatedTodoDTO));
        verify(todoRepository, times(1)).save(any());
    }
}
