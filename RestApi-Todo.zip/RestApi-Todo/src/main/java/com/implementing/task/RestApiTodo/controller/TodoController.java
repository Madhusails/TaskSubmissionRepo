package com.implementing.task.RestApiTodo.controller;

import com.implementing.task.RestApiTodo.Entity.DTO.TodoDTO;
import com.implementing.task.RestApiTodo.Entity.Todo;
import com.implementing.task.RestApiTodo.exceptions.ResourceNotFoundException;
import com.implementing.task.RestApiTodo.repository.TodoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
public class TodoController {
    private TodoRepository repository;
    private ModelMapper modelMapper;

    public TodoController(TodoRepository repository,ModelMapper modelMapper) {
        this.repository = repository;
        this.modelMapper=modelMapper;
    }

    @GetMapping("/tasks")
    public ResponseEntity<List<TodoDTO>> getAll()
    {
        try {
            List<Todo> todoList = repository.findAll();

            if (todoList.isEmpty()) {
                return ResponseEntity.noContent().build();
            } else {
                List<TodoDTO> todoDTOList = todoList.stream()
                        .map(todo -> modelMapper.map(todo, TodoDTO.class))
                        .collect(Collectors.toList());
                return ResponseEntity.ok(todoDTOList);
            }
        } catch (Exception e) {
            // The exception will be caught by the handleException method in GlobalExceptionHandler
            throw new RuntimeException("Exception occurred: " + e.getMessage());
        }
    }
    @GetMapping("/tasks/{id}")
    public ResponseEntity<?> getById(@PathVariable int id) {
        Optional<Todo> todoOptional = repository.findById(id);
        if (todoOptional.isPresent())
        {
            TodoDTO requiredTodo=modelMapper.map(todoOptional, TodoDTO.class);
            return ResponseEntity.ok(requiredTodo);
        }
        else
        {
            throw new ResourceNotFoundException("Todo with ID " + id + " not found");
        }
    }
    @DeleteMapping("/tasks/{id}")
    public ResponseEntity<String> deleteById(@PathVariable int id)
    {
            try {
                Optional<Todo> todoOptional = repository.findById(id);
                if (todoOptional.isPresent()) {
                    repository.deleteById(id);
                    return ResponseEntity.ok("Todo deleted successfully");
                } else {
                    throw new ResourceNotFoundException("Todo with ID " + id + " not found");
                }
            }

            catch(Exception e)
            {
                return ResponseEntity.status(500).body("Error deleting Todo: " + e.getMessage());
            }
    }
    @PostMapping("/tasks")
    public ResponseEntity<String> createTodo(@RequestBody TodoDTO todoDTO)
    {
        try
        {
            Todo todo=modelMapper.map(todoDTO,Todo.class);
            repository.save(todo);
            return ResponseEntity.ok("Todo created successfully");
        }
        catch (Exception e)
        {
            return ResponseEntity.status(500).body("Error creating Todo: " + e.getMessage());
        }
    }
    @PutMapping("/tasks/{id}")
    public ResponseEntity<TodoDTO> updateTodo(@PathVariable int id, @RequestBody TodoDTO updatedTodoDTO)
    {
        try
        {
            Optional<Todo> existingTodoOptional = repository.findById(id);
            if (existingTodoOptional.isPresent()) {
                Todo existingTodo = existingTodoOptional.get();

                // Update only the non-null fields from the updatedTodo
                if (updatedTodoDTO.getName() != null) {
                    existingTodo.setName(updatedTodoDTO.getName());
                }

                if (updatedTodoDTO.getDescription() != null) {
                    existingTodo.setDescription(updatedTodoDTO.getDescription());
                }

                if (updatedTodoDTO.getCreatedDate() != null) {
                    existingTodo.setCreatedDate(updatedTodoDTO.getCreatedDate());
                }
                if (updatedTodoDTO.getModifiedDate() != null) {
                    existingTodo.setModifiedDate(updatedTodoDTO.getModifiedDate());
                }

                if (updatedTodoDTO.getCreatedBy() != null) {
                    existingTodo.setCreatedBy(updatedTodoDTO.getCreatedBy());
                }

                if (updatedTodoDTO.getModifiedBy() != null) {
                    existingTodo.setModifiedBy(updatedTodoDTO.getModifiedBy());
                }
                // Save the updatedTodo back to the repository
                repository.save(existingTodo);
                TodoDTO updatedTodo=modelMapper.map(existingTodo, TodoDTO.class);

                return ResponseEntity.ok(updatedTodo);
            } else {
                // Todo with the given id not found
                return ResponseEntity.notFound().build();
            }
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error updating Todo: " + e.getMessage());
        }
    }




}
