package com.implementing.task.RestApiTodo.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception e) {
        // Log the exception (you might want to use a logging framework like SLF4J here)

        // Return a ResponseEntity with an appropriate error message and status code
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An unexpected error occurred: " + e.getMessage());
    }

    // You can add more specific exception handlers as needed
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<String> handleResourceNotFoundException(ResourceNotFoundException e) {
        // Log the exception

        // Return a ResponseEntity with an appropriate error message and status code
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
    }

}
