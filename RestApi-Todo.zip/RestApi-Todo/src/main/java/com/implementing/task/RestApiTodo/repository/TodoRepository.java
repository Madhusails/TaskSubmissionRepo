package com.implementing.task.RestApiTodo.repository;

import com.implementing.task.RestApiTodo.Entity.Todo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TodoRepository extends JpaRepository<Todo,Integer> {
}
